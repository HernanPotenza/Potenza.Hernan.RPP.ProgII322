package primerparcialformula1;

public enum Compuesto {
    SOFT,
    MEDIUM,
    HARD,
    INTERMEDIO,
    WET
}
