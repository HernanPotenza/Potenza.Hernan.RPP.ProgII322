package primerparcialformula1;

public class PrimerParcialFormula1 {

    public static void main(String[] args) {
        InventarioBox box = new InventarioBox();
        
        //Escenario 1: Agregar piezas (incluye intento duplicado)
        System.out.println("---  Escenario 1: Agregar piezas ---");
        Pieza m1 = new Motor("PU-016", "Estacion Motor", CondicionClimatica.SECO, 980);
        box.agregarPieza(m1);
        
        try{
            // Duplicado: mismo nombre y ubicacion
            Pieza mDup = new Motor("PU-016", "Estacion Motor", CondicionClimatica.LLUVIA, 950);
            box.agregarPieza(mDup);
        } catch(PiezaDuplicadaException ex){
            System.out.println("[EXCEPCION ESPERADA] " + ex.getMessage());
        }
        
        //Agregamos más piezas 
        Pieza a1 = new Ala("Ala-HighDownForce", "Estacion Aero", CondicionClimatica.LLUVIA, 9);
        Pieza n1 = new Neumatico("P-Zero", "Carro Neumatico", CondicionClimatica.LLUVIA, Compuesto.INTERMEDIO);
        Pieza n2 = new Neumatico("P-Zero W", "Carro Neumatico", CondicionClimatica.LLUVIA, Compuesto.WET);
        Pieza a2 = new Ala("Ala-LowDrag", "Estacion Aero", CondicionClimatica.SECO, 3);
        
        box.agregarPieza(a1);
        box.agregarPieza(n1);
        box.agregarPieza(n2);
        box.agregarPieza(a2);
        
        // Escenario 2: Mostrar piezas
        System.out.println("\n--- Escenario 2: Mostrar piezas ---");
        box.mostrarPiezas();
        
        // Escenario 3: Ajuste de piezas
        System.out.println("\n--- Escenario 3: Ajuste de piezas ---");
        box.ajustarPiezas();
        
    }    
}
