package primerparcialformula1;

public abstract class Pieza {
    private String nombre;
    private String ubicacion;
    private CondicionClimatica condicionClimatica;
    
    protected Pieza(String nombre, String ubicacion, CondicionClimatica condicionClimatica){
        if (nombre == null || nombre.isEmpty()) throw new IllegalArgumentException("nombre invalido");
        if (ubicacion == null || ubicacion.isEmpty()) throw new IllegalArgumentException("ubicacion invalido");
        if (condicionClimatica == null) throw new IllegalArgumentException("condicionClimatica invalido");
        
        this.nombre = nombre.trim();
        this.ubicacion = ubicacion.trim();
        this.condicionClimatica = condicionClimatica;   
    }
    
    public String getNombre(){
        return nombre;
    }
    
    public String getUbicacion(){
        return ubicacion;
    }
    
    public CondicionClimatica getCondicionClimatica(){
        return condicionClimatica;
    }
    
    @Override
    public boolean equals(Object o){
        if (this == o) return true;
        if(!(o instanceof Pieza)) return false;
        Pieza pieza = (Pieza) o;
        return nombre.equalsIgnoreCase(pieza.nombre)
                && ubicacion.equalsIgnoreCase(pieza.ubicacion);
    }
    
    protected String mostrar(){
        StringBuilder sb = new StringBuilder();
        sb.append("nombre='").append(nombre).append("', ubicacion='")
                .append(ubicacion).append("', condicion='").append(condicionClimatica);
        return sb.toString();
    }
    
    @Override
    public String toString(){
        return this.mostrar();
    }
            
    
}
