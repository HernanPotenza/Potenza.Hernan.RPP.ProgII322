package primerparcialformula1;

import java.util.ArrayList;
import java.util.List;

public class InventarioBox {

    private ArrayList<Pieza> piezas = new ArrayList<>();

    //public InventarioBox(){
    //this.piezas = new ArrayList<Pieza>();
    //}
    public void agregarPieza(Pieza pieza) {
        if (pieza == null) {
            throw new IllegalArgumentException("pieza nula");
        }

        if (piezas.contains(pieza)) {
            throw new PiezaDuplicadaException("Ya existe una pieza con el mismo nombre y ubicacion: ("
                    + pieza.getNombre() + ", " + pieza.getUbicacion() + ")"
            );
        }

        piezas.add(pieza);
    }

    public void mostrarPiezas() {
        if (piezas.isEmpty()) {
            System.out.println("[INFO] No hay piezas registradas");
            return;
        }

        System.out.println("--- LISTA DE PIEZAS ---");
        piezas.forEach(p -> System.out.println("- " + p));
        System.out.println("--------------");

    }

    public void ajustarPiezas() {
        if (piezas.isEmpty()) {
            System.out.println("[INFO] No hay piezas registradas para ajustar.");
            return;
        }

        System.out.println("--- AJUSTE DE PIEZAS ---");
        for (Pieza p : piezas) {
            if (p instanceof Ajustable) {
                ((Ajustable) p).ajustar();
            } else {
                System.out.printf("[INFO] La pieza '%s' (Neumatico) no se ajusta: se monta/cambia.%n", p.getNombre());
            }
        } 
        System.out.println("-----------------");
    }
    
    public List<Pieza> buscarPiezasPorCondicion(CondicionClimatica condicion){
        if (condicion == null) throw new IllegalArgumentException("condicion nula"); 
        
        List<Pieza> resultado = new ArrayList<>();
        
        for(Pieza p : piezas){
            if(p.getCondicionClimatica() == condicion){
                resultado.add(p);
            }
        }
        
        System.out.printf("--- BUSQUEDA POR CONDICION: %s --- %n", condicion);
        
        if(resultado.isEmpty()){
            System.out.println("[INFO] No hay piezas para esa condicion");
        } else {
            resultado.forEach(p -> System.out.println("- " + p));
        }
        
        System.out.println("-------------------------");
        return resultado;
    }

}
