package primerparcialformula1;

public interface Ajustable {
    void ajustar();    
}
