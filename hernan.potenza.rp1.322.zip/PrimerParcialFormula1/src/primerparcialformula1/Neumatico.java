package primerparcialformula1;

public class Neumatico extends Pieza{
    private final Compuesto compuesto;
    
    public Neumatico(String nombre, String ubicacion, CondicionClimatica condicion, Compuesto compuesto){
        super(nombre, ubicacion, condicion);
        
        if (compuesto == null) throw new IllegalArgumentException("compuesto invalido");
        
        this.compuesto = compuesto;
    }
    
    public Compuesto getCompuesto(){
        return compuesto;
    }
    
    @Override
    public String toString(){
        return "Neumatico{" + super.toString() + ", compuesto=" + compuesto + "}";
    }
    
}
