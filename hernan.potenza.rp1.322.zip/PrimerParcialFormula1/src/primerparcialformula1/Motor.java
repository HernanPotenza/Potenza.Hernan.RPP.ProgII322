package primerparcialformula1;

public class Motor extends Pieza implements Ajustable{
    private int potenciaMaximaCv;
    
    public Motor(String nombre, String ubicacion, CondicionClimatica condicion, int potenciaMaximaCv){
        super(nombre, ubicacion, condicion);
        if(potenciaMaximaCv <= 0) throw new IllegalArgumentException("potenciaMaximaCv debe ser > 0");
        
        this.potenciaMaximaCv = potenciaMaximaCv;
    }
    
    public int getPotenciaMaximaCv()
    {
        return potenciaMaximaCv;
    }
    
    @Override
    public void ajustar(){
        System.out.printf("[AJUSTE] Motor '%s': calibrando mapeo electronico... %n", getNombre());
    }
    
    @Override
    public String toString(){
        return "Motor{" + super.toString() + ", potenciaMaximaCv=" + potenciaMaximaCv + "}";
    }
    
    
}
