package primerparcialformula1;

public class Ala extends Pieza implements Ajustable{
    private int cargaAerodinamica;
    //final int MAX = 10;
    //final int MIN = 1;
    
    
    public Ala(String nombre, String ubicacion, CondicionClimatica condicion, int cargaAerodinamica){
        super(nombre, ubicacion, condicion);
        if(cargaAerodinamica < 1 || cargaAerodinamica > 10) {
            throw new IllegalArgumentException("cargaAerodinamica debe estar entre 1 y 10");
        }
        
        this.cargaAerodinamica = cargaAerodinamica;
        
    }
    
    public int getCargaAerodinamica()
    {
        return cargaAerodinamica;
    }
    
    @Override
    public void ajustar(){
        System.out.printf("[AJUSTE] Ala '%s': ajustando angulo de flap... %n", getNombre());
    }
    
    @Override
    public String toString(){
        return "Ala{" + super.toString() + ", cargaAerodinamica=" + cargaAerodinamica + "}";
    }
    
}
