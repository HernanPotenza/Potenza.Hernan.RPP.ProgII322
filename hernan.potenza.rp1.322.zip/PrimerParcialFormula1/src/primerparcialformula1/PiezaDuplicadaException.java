package primerparcialformula1;

public class PiezaDuplicadaException extends RuntimeException {
    public PiezaDuplicadaException(String msg){
        super(msg);
    }
    
}
