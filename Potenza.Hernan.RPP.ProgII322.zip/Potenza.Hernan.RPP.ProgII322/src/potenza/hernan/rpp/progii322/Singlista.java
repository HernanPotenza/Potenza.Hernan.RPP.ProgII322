package potenza.hernan.rpp.progii322;

public class Singlista extends Jugador implements Sacar{
    private int velocidadDeSaque;
    
    public Singlista(String nombre, int ranking, Superficie superficie, int velocidadDeSaque){
        super(nombre, ranking, superficie);
        if(velocidadDeSaque <= 0) throw new IllegalArgumentException("Velocidad de saque debe ser mayor a 0");
        
        this.velocidadDeSaque = velocidadDeSaque;
    }

    public int getVelocidadDeSaque() {
        return velocidadDeSaque;
    }
    
    @Override
    public void sacar(){
        System.out.printf("[SAQUE] Singlista sacando a una velocidad de '%d': %n", getVelocidadDeSaque());
    }
    
    @Override
    public String toString(){
        return "Singlista{" + super.toString() + ", velocidad de saque = " + velocidadDeSaque + "}";
    }    
    
}
