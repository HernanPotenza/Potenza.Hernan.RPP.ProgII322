package potenza.hernan.rpp.progii322;

public class PotenzaHernanRPPProgII322 {

    public static void main(String[] args) {
        GestionTorneo Torneo = new GestionTorneo();

        //Escenario 1 y 2: Agregar y mostrar jugadores (incluye intento duplicado)
        System.out.println("---  Escenario 1: Agregar jugadores ---");
        Jugador s1 = new Singlista("David Nalbandian", 3, Superficie.CEMENTO, 15);
        Jugador s2 = new Singlista("Pepe", 3, Superficie.CESPED, 16);
        Jugador s3 = new Singlista("David Nalbandian", 3, Superficie.CEMENTO, 15);
        Jugador d1 = new Doblista("Hernan", 3, Superficie.CESPED, 5);
        Jugador d2 = new Doblista("Cristian", 2, Superficie.POLVO, 8);
        Jugador j1 = new Juvenil("Jose Luis", 1, Superficie.POLVO, true);
        Jugador j2 = new Juvenil("Magali", 5, Superficie.CEMENTO, false);

        Torneo.agregarJugador(s1);
        Torneo.agregarJugador(s2);
        Torneo.agregarJugador(d1);
        Torneo.agregarJugador(d2);
        Torneo.agregarJugador(j1);
        Torneo.agregarJugador(j2);
        Torneo.mostrarJugadores();

        try {
            Torneo.agregarJugador(s3);

        } catch (JugadorDuplicadoException ex) {
            System.out.println("[EXCEPCION ESPERADA] " + ex.getMessage());
        }
        
        //Escenario 3: 
        
        Torneo.saqueYPracticaEnPareja();
        
        //Escenario 4: filtrar por superficie
        
        Torneo.filtrarPorSuperficie(Superficie.POLVO);
        
        //Escenario 5: generar resumen por tipo
        
        System.out.println("Cantidad de jugadores por tipo: (Singlista, Doblista, Juvenil)" + Torneo.generarResumenPorTipo());
        
        
        

    }

}

/*InventarioBox box = new InventarioBox();
        
        //Escenario 1: Agregar piezas (incluye intento duplicado)
        System.out.println("---  Escenario 1: Agregar piezas ---");
        Pieza m1 = new Motor("PU-016", "Estacion Motor", CondicionClimatica.SECO, 980);
        box.agregarPieza(m1);
        
        try{
            // Duplicado: mismo nombre y ubicacion
            Pieza mDup = new Motor("PU-016", "Estacion Motor", CondicionClimatica.LLUVIA, 950);
            box.agregarPieza(mDup);
        } catch(PiezaDuplicadaException ex){
            System.out.println("[EXCEPCION ESPERADA] " + ex.getMessage());
        }
        
        //Agregamos más piezas 
        Pieza a1 = new Ala("Ala-HighDownForce", "Estacion Aero", CondicionClimatica.LLUVIA, 9);
        Pieza n1 = new Neumatico("P-Zero", "Carro Neumatico", CondicionClimatica.LLUVIA, Compuesto.INTERMEDIO);
        Pieza n2 = new Neumatico("P-Zero W", "Carro Neumatico", CondicionClimatica.LLUVIA, Compuesto.WET);
        Pieza a2 = new Ala("Ala-LowDrag", "Estacion Aero", CondicionClimatica.SECO, 3);
        
        box.agregarPieza(a1);
        box.agregarPieza(n1);
        box.agregarPieza(n2);
        box.agregarPieza(a2);
        
        // Escenario 2: Mostrar piezas
        System.out.println("\n--- Escenario 2: Mostrar piezas ---");
        box.mostrarPiezas();
        
        // Escenario 3: Ajuste de piezas
        System.out.println("\n--- Escenario 3: Ajuste de piezas ---");
        box.ajustarPiezas();*/
