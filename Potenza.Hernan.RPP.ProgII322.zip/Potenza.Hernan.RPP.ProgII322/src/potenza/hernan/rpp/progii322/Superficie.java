package potenza.hernan.rpp.progii322;

public enum Superficie {
    POLVO,
    CESPED,
    CEMENTO
    
}
