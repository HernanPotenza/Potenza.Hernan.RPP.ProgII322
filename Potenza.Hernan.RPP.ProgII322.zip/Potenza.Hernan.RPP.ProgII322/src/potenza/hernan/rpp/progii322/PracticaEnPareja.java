package potenza.hernan.rpp.progii322;


public interface PracticaEnPareja {
    void practicaEnPareja();    
}
