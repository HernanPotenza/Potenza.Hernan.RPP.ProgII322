package potenza.hernan.rpp.progii322;

public class JugadorDuplicadoException extends RuntimeException{
    public JugadorDuplicadoException(String msg){
        super(msg);
    }
}