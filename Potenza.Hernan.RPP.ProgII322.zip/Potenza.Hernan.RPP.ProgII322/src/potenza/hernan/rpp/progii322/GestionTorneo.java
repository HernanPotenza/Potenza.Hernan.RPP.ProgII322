package potenza.hernan.rpp.progii322;

import java.util.ArrayList;
import java.util.List;

public class GestionTorneo {

    private ArrayList<Jugador> jugadores = new ArrayList<>();

    public void agregarJugador(Jugador jugador) {
        if (jugador == null) {
            throw new IllegalArgumentException("Jugador nulo");
        }

        if (jugadores.contains(jugador)) {
            throw new JugadorDuplicadoException("Ya existe un jugador con el mismo nombre y ranking: ("
                    + jugador.getNombre() + ", " + jugador.getRanking() + ")"
            );
        }
        jugadores.add(jugador);
    }

    public void mostrarJugadores() {
        if (jugadores.isEmpty()) {
            System.out.println("[INFO] No hay jugadores registrados");
            return;
        }

        System.out.println("--- LISTA DE JUGADORES ---");
        jugadores.forEach(j -> System.out.println("- " + j));
        System.out.println("--------------");

    }

    public List<Integer> generarResumenPorTipo() {
        int cantidadSinglistas = 0;
        int cantidadDoblistas = 0;
        int cantidadJuveniles = 0;

        List<Integer> conteoJugadores = new ArrayList<>();

        for (Jugador j : jugadores) {
            if (j instanceof Singlista) {
                cantidadSinglistas++;
            } else if (j instanceof Doblista) {
                cantidadDoblistas++;
            } else if (j instanceof Juvenil) {
                cantidadJuveniles++;
            }
        }

        conteoJugadores.add(cantidadSinglistas);
        conteoJugadores.add(cantidadDoblistas);
        conteoJugadores.add(cantidadJuveniles);

        return conteoJugadores;

    }

    public List<Jugador> filtrarPorSuperficie(Superficie superficie) {
        if (superficie == null) {
            throw new IllegalArgumentException("Superficie nula");
        }

        List<Jugador> resultado = new ArrayList<>();

        for (Jugador j : jugadores) {
            if (j.getSuperficie() == superficie) {
                resultado.add(j);
            }
        }

        System.out.printf("--- BUSQUEDA POR SUPERFICIE: %s --- %n", superficie);

        if (resultado.isEmpty()) {
            System.out.println("[INFO] No hay jugadores para esa superficie");
        } else {
            resultado.forEach(j -> System.out.println("- " + j));
        }

        System.out.println("-------------------------");
        return resultado;
    }

    public void saqueYPracticaEnPareja() {
        if (jugadores.isEmpty()) {
            System.out.println("[INFO] No hay jugadores registrados para sacar o practicar.");
            return;
        }

        System.out.println("--- SAQUE Y PRACTICA EN PAREJAS---");
        for (Jugador j : jugadores) {
            if (j instanceof Sacar) {
                if (j instanceof PracticaEnPareja) {
                    ((Sacar) j).sacar();
                    ((PracticaEnPareja) j).practicaEnPareja();
                } else {
                    ((Sacar) j).sacar();
                }
            } else if (j instanceof PracticaEnPareja) {
                ((PracticaEnPareja) j).practicaEnPareja();
            }
        }
        System.out.println("-----------------");
    }

}


/*public void ajustarPiezas() {
        if (piezas.isEmpty()) {
            System.out.println("[INFO] No hay piezas registradas para ajustar.");
            return;
        }

        System.out.println("--- AJUSTE DE PIEZAS ---");
        for (Pieza p : piezas) {
            if (p instanceof Ajustable) {
                ((Ajustable) p).ajustar();
            } else {
                System.out.printf("[INFO] La pieza '%s' (Neumatico) no se ajusta: se monta/cambia.%n", p.getNombre());
            }
        } 
        System.out.println("-----------------");
    }*/
