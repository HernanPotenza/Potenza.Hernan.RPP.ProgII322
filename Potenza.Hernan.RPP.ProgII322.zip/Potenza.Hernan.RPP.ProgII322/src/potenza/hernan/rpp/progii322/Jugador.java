package potenza.hernan.rpp.progii322;


public class Jugador {
    private String nombre;
    private int ranking;
    private Superficie superficie;
    
    protected Jugador(String nombre, int ranking, Superficie superficie){
        if (nombre == null || nombre.isEmpty()) throw new IllegalArgumentException("Nombre invalido");
        if (ranking == 0) throw new IllegalArgumentException("Ranking invalido");
        if (superficie == null) throw new IllegalArgumentException("Superficie invalida");
        
        this.nombre = nombre.trim();
        this.ranking = ranking;
        this.superficie = superficie;   
    }
    
    public String getNombre(){
        return nombre;
    }
    
    public int getRanking(){
        return ranking;
    }
    
    public Superficie getSuperficie(){
        return superficie;
    }
    
    @Override
    public boolean equals(Object o){
        if (this == o) return true;
        if(!(o instanceof Jugador)) return false;
        Jugador jugador = (Jugador) o;
        return nombre.equalsIgnoreCase(jugador.nombre)
                && ranking == (jugador.ranking);
    }
    
    protected String mostrar(){
        StringBuilder sb = new StringBuilder();
        sb.append("nombre='").append(nombre).append("', ranking='")
                .append(ranking).append("', superficie ='").append(superficie);
        return sb.toString();
    }
    
    @Override
    public String toString(){
        return this.mostrar();
    }
    
}
