package potenza.hernan.rpp.progii322;

public interface Sacar {
    void sacar();    
}
