package potenza.hernan.rpp.progii322;


public class Juvenil extends Jugador implements PracticaEnPareja{
    private boolean poseeTutor;
    
    public Juvenil(String nombre, int ranking, Superficie superficie, boolean poseeTutor){
        super(nombre, ranking, superficie);        
        this.poseeTutor = poseeTutor;        
    }

    public boolean isPoseeTutor() {
        return poseeTutor;
    }
    
    @Override
    public void practicaEnPareja(){
        System.out.println("[PRACTICA EN PAREJA] Juvenil practicando en pareja");
    } 
    
    @Override
    public String toString(){
        return "Juvenil{" + super.toString() + ", posee tutor = " + poseeTutor + "}";
    }    
        
}


