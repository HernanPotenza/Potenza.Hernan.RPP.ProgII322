package potenza.hernan.rpp.progii322;


public class Doblista extends Jugador implements Sacar, PracticaEnPareja{
    private int indiceCoordinacion;
    
    public Doblista(String nombre, int ranking, Superficie superficie, int indiceCoordinacion){
        super(nombre, ranking, superficie);
        if(indiceCoordinacion < 1 || indiceCoordinacion > 10) throw new IllegalArgumentException("Indice de coordinacion debe estar entre 1 y 10");
        
        this.indiceCoordinacion = indiceCoordinacion;        
    }

    public int getIndiceCoordinacion() {
        return indiceCoordinacion;
    }
    
    @Override
    public void sacar(){
        System.out.printf("[SAQUE] Doblista sacando %n");
    }
    
    @Override
    public void practicaEnPareja(){
        System.out.println("[PRACTICA EN PAREJA] Doblista practicando en pareja");
    } 
    
    @Override
    public String toString(){
        return "Doblista{" + super.toString() + ", indice de coordinacion = " + indiceCoordinacion + "}";
    }    
    
}

